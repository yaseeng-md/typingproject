from django.urls import path
from.import views

urlpatterns = [
    path("",views.navbar,name='navbar'),
    path("aboutus",views.aboutus,name = 'aboutus'),
    path("aboutproject",views.aboutproject,name = 'aboutproject'),
]
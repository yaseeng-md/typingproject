from django.shortcuts import render


def navbar(req):
    return render(req,'navbar.html')
def aboutus(req):
    return render(req, 'aboutus.html')

def aboutproject(req):
    return render(req, 'aboutproject.html')
